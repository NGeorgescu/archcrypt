cd "$(find /home -mindepth 1 -maxdepth 1 -type d | head -1)"
git clone https://github.com/ngeorgescu/dotfiles.git



