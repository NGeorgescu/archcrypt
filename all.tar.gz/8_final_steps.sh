#!/bin/bash
exit && \
umount -R /mnt && \
shutdown -r now
